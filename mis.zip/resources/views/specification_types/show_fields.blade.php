<!-- Spec Type Field -->
<div class="col-sm-12">
    {!! Form::label('spec_type', 'Spec Type:') !!}
    <p>{{ $specificationType->spec_type }}</p>
</div>

<!-- Description Field -->
<div class="col-sm-12">
    {!! Form::label('description', 'Description:') !!}
    <p>{{ $specificationType->description }}</p>
</div>

<!-- Image Field -->
<div class="col-sm-12">
    {!! Form::label('image', 'Image:') !!}
    <p>{{ $specificationType->image }}</p>
</div>

<!-- Specification Id Field -->
<div class="col-sm-12">
    {!! Form::label('specification_id', 'Specification Id:') !!}
    <p>{{ $specificationType->specification_id }}</p>
</div>

